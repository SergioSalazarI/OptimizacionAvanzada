
print('-Python: �Hola mundo!')
name=input('�Como te llamas?')
print(f'-Python: �Hola {name}!')


